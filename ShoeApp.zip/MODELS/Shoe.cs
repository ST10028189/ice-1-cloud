﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace $safeprojectname$.Models
{
    public class Shoe
    {
        public int Id { get; set; }
        public string? Brand { get; set; }
        [Display(Name = "Colour")]
     
        public string? Colour { get; set; }
        public string? Size { get; set; }
        [Column(TypeName = "decimal(18, 2)")]
        public decimal Price { get; set; }
    }
}
