﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using $safeprojectname$.Data;
using System;
using System.Linq;

namespace $safeprojectname$.Models;

public static class SeedData
{
    public static void Initialize(IServiceProvider serviceProvider)
    {
        using (var context = new ShoeAppContext(
            serviceProvider.GetRequiredService<
                DbContextOptions<ShoeAppContext>>()))
        {
            // Look for any movies.
            if (context.Shoe.Any())
            {
                return;   // DB has been seeded
            }
            context.Shoe.AddRange(
                new Shoe
                {
                    Brand = "Puma",
                    Colour = "Red",
                    Size = "11",
                    Price = 799.99M
                },
                new Shoe
                {
                    Brand = "Vans",
                    Colour = "Blue",
                    Size = "8",
                    Price = 1299.99M
                },
                new Shoe
                {
                    Brand = "Adidas",
                    Colour = "Green",
                    Size = "9",
                    Price = 999.99M
                },
                new Shoe
                {
                    Brand = "New Rock",
                    Colour = "Black",
                    Size = "9",
                    Price = 1299.99M
                }
            );
            context.SaveChanges();
        }
    }
}